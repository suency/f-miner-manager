<template>
	<view class="content">
		<view class="title">
			<view>爆块信息</view>
			<view class="center">刷新</view>
		</view>
		<view class="baoinfo">
			<view class="bar">
				
			</view>
			<view class="top">
				<view class="text">
					<view>Miner:</view>
					<view>f03001</view>
				</view>
				<view class="text">
					<view>Power:</view>
					<view>4.656 TiB / 81.49 PiB (0.0055%)</view>
				</view>
				<view class="text">
					<view>Expected:</view>
					<view>0.7920/day (every 30h18m10s)</view>
				</view>
				<view class="text">
					<view>Miner Balance:</view>
					<view>45.393446999828800589</view>
				</view>
				<view class="text">
					<view>Vesting:</view>
					<view>44.029241467827719986</view>
				</view>
				<view class="text">
					<view>Available:</view>
					<view>1.364205532001080603</view>
				</view>
				<view class="text">
					<view>Worker Balance:</view>
					<view>1.091400336047343616</view>
				</view>
			</view>
			<view class="bottom">
				<view class="text">
					<view>Total:</view>
					<view>618</view>
				</view>
				<view class="text">
					<view>Total:</view>
					<view>618</view>
				</view>
				<view class="text">
					<view>Total:</view>
					<view>618</view>
				</view>
			</view>
		</view>
		
		<view class="title" style="margin-top: 60rpx;">
			<view>主机任务</view>
			<view style="visibility: hidden;">主机任务</view>
		</view>
		<view class="jobs">
			<view class="job">
				<text space="emsp">asd asd    asadas</text>
				<view class="bar1">
					
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: 'Hello2'
			}
		},
		onLoad() {

		},
		methods: {

		}
	}
</script>

<style>
	.bold{
		font-weight: bold;
	}
	.center{
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.content {
		box-sizing: border-box;
		padding: 60rpx;
	}
	
	.title {
		font-size: 36rpx;
		display: flex;
		justify-content: space-between;
	}
	
	.title>view:last-child{
		width: 154rpx;
		height: 54rpx;
		background: #A880E3;
		border-radius: 6rpx;
		color:#FFFFFF;
		font-size: 28rpx;
	}
	
	.baoinfo{
		width: 100%;
		background: #FFFFFF;
		box-shadow: 0rpx 4rpx 12rpx rgba(188, 188, 188, 0.5);
		border-radius: 10rpx;
		margin-top: 26rpx;
		box-sizing: border-box;
		padding: 36rpx;
		font-size: 28rpx;
		position: relative;
		/* height: 300rpx; */
	}
	
	.text{
		display: flex;
	}
	.text>view:first-child{
		font-weight: bold;
		margin-right: 10rpx;
	}
	
	.bottom{
		margin-top: 42rpx;
	}
	
	.bar{
		width: 10rpx;
		height: 300rpx;
		background-color: #A880E3;
		border-radius: 6rpx;
		position: absolute;
		left:-5rpx;
		top:50%;
		transform: translateY(-50%);
	}
	
	.job{
		width: 100%;
		height: 326rpx;
		background: #FFFFFF;
		box-shadow: 0rpx 4rpx 12rpx rgba(188, 188, 188, 0.5);
		border-radius: 10rpx;
		margin-top: 26rpx;
		position: relative;
	}
	
	.bar1{
		width: 10rpx;
		height: 200rpx;
		background-color: #53D7FF;
		border-radius: 6rpx;
		position: absolute;
		left:-5rpx;
		top:50%;
		transform: translateY(-50%);
	}
</style>
